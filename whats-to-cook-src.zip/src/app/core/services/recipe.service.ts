import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Recipe } from '../../models/recipe.model';

@Injectable({ providedIn: 'root' })
export class RecipeService {
  private readonly API = 'https://dummyjson.com/recipes';

  constructor(private http: HttpClient) {}

  // fetch paginated envelope; we map to recipes array for simplicity
  fetchAll(params: { limit?: number; skip?: number } = {}) {
    const url = this.API + (params.limit ? `?limit=${params.limit}&skip=${params.skip || 0}` : '');
    return this.http.get<any>(url).pipe(map((env: any) => env.recipes || env));
  }

  fetchById(id: number) {
    return this.http.get<Recipe>(`${this.API}/${id}`);
  }
}
