import { Injectable, signal, computed, effect } from '@angular/core';
import { Recipe } from '../../models/recipe.model';
import { RecipeService } from '../services/recipe.service';
import { toSignal } from '@angular/core/rxjs-interop';

@Injectable({ providedIn: 'root' })
export class RecipeStore {
  // source of truth for recipes
  recipes = signal<Recipe[]>([]);

  // UI state
  searchQuery = signal<string>('');
  ingredientQuery = signal<string>('');
  cuisineQuery = signal<string>('');

  // favourites set of ids
  favourites = signal<Set<number>>(new Set());

  // derived list: applies filters reactively
  filteredRecipes = computed(() => {
    const q = this.searchQuery().trim().toLowerCase();
    const ing = this.ingredientQuery().trim().toLowerCase();
    const cuisine = this.cuisineQuery().trim().toLowerCase();

    return this.recipes().filter(r => {
      const title = (r.title || '').toLowerCase();
      const matchesQ = q ? title.includes(q) || (r.instructions || '').toLowerCase().includes(q) : true;
      const matchesCuisine = cuisine ? (r.cuisine || '').toLowerCase().includes(cuisine) : true;
      const matchesIng = ing ? r.ingredients.some(i => i.toLowerCase().includes(ing)) : true;
      return matchesQ && matchesCuisine && matchesIng;
    });
  });

  constructor(private api: RecipeService) {
    // load recipes from API into the recipes signal using toSignal + effect
    const obsSignal = toSignal(this.api.fetchAll({ limit: 50 }), { initialValue: null as any });
    effect(() => {
      const v = obsSignal();
      if (Array.isArray(v)) this.recipes.set(v as Recipe[]);
    });

    // hydrate favourites from localStorage
    const raw = localStorage.getItem('wtc_favourites');
    if (raw) {
      try {
        const arr = JSON.parse(raw) as number[];
        this.favourites.set(new Set(arr));
      } catch { }
    }

    // persist favourites whenever it changes
    effect(() => {
      const arr = Array.from(this.favourites());
      localStorage.setItem('wtc_favourites', JSON.stringify(arr));
    });
  }

  toggleFavourite(id: number) {
    const s = new Set(this.favourites());
    if (s.has(id)) s.delete(id); else s.add(id);
    this.favourites.set(s);
  }
}
