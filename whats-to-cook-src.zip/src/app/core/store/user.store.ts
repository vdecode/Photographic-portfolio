import { Injectable, signal, effect } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class UserStore {
  // null = logged out, otherwise username string
  user = signal<string | null>(null);

  constructor() {
    const raw = localStorage.getItem('wtc_user');
    if (raw) this.user.set(raw);

    effect(() => {
      const u = this.user();
      if (u) localStorage.setItem('wtc_user', u); else localStorage.removeItem('wtc_user');
    });
  }

  login(username: string) {
    // mock login - accepts any username/password in this demo
    this.user.set(username);
  }

  logout() {
    this.user.set(null);
  }
}
