import { Injectable, signal, effect } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ThemeStore {
  dark = signal<boolean>(false);

  constructor() {
    const raw = localStorage.getItem('wtc_dark');
    this.dark.set(raw === '1');

    effect(() => {
      const d = this.dark();
      const html = document.documentElement;
      if (d) html.classList.add('dark'); else html.classList.remove('dark');
      localStorage.setItem('wtc_dark', d ? '1' : '0');
    });
  }

  toggle() { this.dark.update(v => !v); }
}
