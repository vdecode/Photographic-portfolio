import { Routes } from '@angular/router';
import { HomePage } from './pages/home/home.page';
import { RecipesPage } from './pages/recipes/recipes.page';
import { RecipeDetailsPage } from './pages/recipe-details/recipe-details.page';
import { FavouritesPage } from './pages/favourites/favourites.page';
import { LoginPage } from './pages/login/login.page';

export const appRoutes: Routes = [
  { path: '', component: HomePage },
  { path: 'login', component: LoginPage },
  { path: 'recipes', component: RecipesPage },
  { path: 'recipes/:id', component: RecipeDetailsPage },
  { path: 'favourites', component: FavouritesPage },
  { path: '**', redirectTo: '' },
];
