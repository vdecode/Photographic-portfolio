export interface Recipe {
  id: number;
  title: string;
  cuisine?: string;
  ingredients: string[];
  instructions?: string;
  images?: string[];
  thumbnail?: string;
  servings?: number;
  prepTime?: string;
}
