import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Recipe } from '../../models/recipe.model';
import { RecipeStore } from '../../core/store/recipe.store';

@Component({
  selector: 'recipe-card',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <article class="card">
      <img *ngIf="recipe.images?.length; else noimg" [src]="recipe.images[0]" alt="" />
      <ng-template #noimg><div style="height:140px;background:#f3f4f6;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#9aa0b4">No image</div></ng-template>
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div>
          <h3 style="margin:0;font-size:1rem">{{ recipe.title }}</h3>
          <div class="muted">{{ recipe.cuisine || '—' }}</div>
        </div>
        <div style="display:flex;flex-direction:column;gap:0.25rem;align-items:flex-end">
          <button class="fav-btn" (click)="toggle()">{{ store.favourites().has(recipe.id) ? '♥' : '♡' }}</button>
          <a [routerLink]="['/recipes', recipe.id]" style="font-size:0.85rem;color:var(--accent)">View</a>
        </div>
      </div>
    </article>
  `,
  styles: [`.fav-btn{background:transparent;border:0;font-size:1.15rem;cursor:pointer}`]
})
export class RecipeCardComponent {
  @Input() recipe!: Recipe;
  constructor(public store: RecipeStore) {}
  toggle(){ this.store.toggleFavourite(this.recipe.id); }
}
