import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ThemeStore } from '../../core/store/theme.store';
import { UserStore } from '../../core/store/user.store';

@Component({
  selector: 'navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <nav style="display:flex;align-items:center;gap:0.75rem">
      <a routerLink="/" style="text-decoration:none;color:inherit">Home</a>
      <a routerLink="/recipes" style="text-decoration:none;color:inherit">Recipes</a>
      <a routerLink="/favourites" style="text-decoration:none;color:inherit">Favourites</a>
      <a *ngIf="!user.user()" routerLink="/login" style="text-decoration:none;color:inherit">Login</a>
      <button (click)="theme.toggle()" style="padding:0.35rem 0.5rem;border-radius:8px;border:1px solid #eee;cursor:pointer">{{ theme.dark() ? 'Light' : 'Dark' }}</button>
      <button *ngIf="user.user()" (click)="logout()" style="padding:0.35rem;border-radius:8px;border:1px solid #eee;cursor:pointer">Logout</button>
    </nav>
  `,
})
export class NavbarComponent {
  constructor(public theme: ThemeStore, public user: UserStore) {}
  logout(){ this.user.logout(); }
}
