import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { UserStore } from '../../core/store/user.store';

@Component({
  selector: 'login-page',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section style="max-width:520px;margin:0 auto;background:var(--card);padding:1rem;border-radius:10px;box-shadow:var(--shadow)">
      <h2>Login</h2>
      <p class="muted">This is a mock login for the demo. Enter any username.</p>
      <form (submit)="submit($event)">
        <div style="display:flex;flex-direction:column;gap:0.5rem">
          <input type="text" name="username" placeholder="Username" required />
          <input type="password" name="password" placeholder="Password" required />
          <div style="display:flex;gap:0.5rem;margin-top:0.5rem">
            <button type="submit" style="padding:0.5rem 0.75rem;border-radius:8px;border:none;background:var(--accent);color:#fff">Login</button>
            <a routerLink="/" style="align-self:center;color:var(--muted)">Cancel</a>
          </div>
        </div>
      </form>
    </section>
  `,
})
export class LoginPage {
  constructor(private user: UserStore, private router: Router){}
  submit(e: Event){ e.preventDefault(); const form = e.target as HTMLFormElement; const username = (form.username as HTMLInputElement).value; this.user.login(username); this.router.navigateByUrl('/recipes'); }
}
