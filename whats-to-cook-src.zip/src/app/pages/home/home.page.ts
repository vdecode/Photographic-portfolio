import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { RecipeStore } from '../../core/store/recipe.store';
import { RecipeCardComponent } from '../../components/recipe-card/recipe-card.component';

@Component({
  selector: 'home-page',
  standalone: true,
  imports: [CommonModule, RouterModule, RecipeCardComponent],
  template: `
    <section class="hero">
      <div>
        <h1 style="margin:0">Find what\'s to cook today</h1>
        <p class="muted">A tidy recipe demo built with Angular Signals — great for your resume.</p>
        <div style="margin-top:1rem"><a routerLink="/recipes"><button class="cta">Explore Recipes</button></a></div>
      </div>
      <div style="width:420px">
        <div class="grid">
          <recipe-card *ngFor="let r of featured" [recipe]="r"></recipe-card>
        </div>
      </div>
    </section>
  `,
})
export class HomePage {
  featured = [] as any[];
  constructor(public store: RecipeStore){
    // pick first 4 as featured (reactively)
    this.featured = store.recipes().slice(0,4);
  }
}
