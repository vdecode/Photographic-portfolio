import { Component, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { RecipeStore } from '../../core/store/recipe.store';

@Component({
  selector: 'recipe-details-page',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <section *ngIf="recipe; else loading">
      <div style="display:flex;gap:1.25rem;align-items:flex-start">
        <img *ngIf="recipe.images?.length" [src]="recipe.images[0]" style="width:320px;height:220px;object-fit:cover;border-radius:10px"/>
        <div>
          <h2 style="margin-top:0">{{ recipe.title }}</h2>
          <div class="muted">{{ recipe.cuisine }}</div>
          <h4>Ingredients</h4>
          <ul><li *ngFor="let i of recipe.ingredients">{{ i }}</li></ul>
          <h4>Instructions</h4>
          <p>{{ recipe.instructions }}</p>
          <div style="margin-top:0.75rem">
            <button (click)="toggleFav()" style="padding:0.5rem 0.75rem;border-radius:8px;border:none;background:var(--accent);color:#fff">{{ store.favourites().has(recipe.id) ? 'Remove Favourite' : 'Add to Favourite' }}</button>
            <a routerLink="/recipes" style="margin-left:0.75rem;color:var(--accent)">Back to recipes</a>
          </div>
        </div>
      </div>
    </section>
    <ng-template #loading><div>Loading...</div></ng-template>
  `,
})
export class RecipeDetailsPage {
  recipe: any = null;
  constructor(private route: ActivatedRoute, public store: RecipeStore){
    const id = Number(this.route.snapshot.paramMap.get('id'));
    effect(() => {
      const r = store.recipes().find(x => Number(x.id) === Number(id));
      this.recipe = r || null;
    });
  }

  toggleFav(){ if(this.recipe) this.store.toggleFavourite(this.recipe.id); }
}
