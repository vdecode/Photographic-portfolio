import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RecipeStore } from '../../core/store/recipe.store';
import { RecipeCardComponent } from '../../components/recipe-card/recipe-card.component';

@Component({
  selector: 'recipes-page',
  standalone: true,
  imports: [CommonModule, RecipeCardComponent],
  template: `
    <section>
      <div style="display:flex;align-items:center;justify-content:space-between;gap:1rem;margin-bottom:0.75rem">
        <div class="searchbar" style="flex:1">
          <input type="text" placeholder="Search title or instructions" [value]="store.searchQuery()" (input)="store.searchQuery.set($any($event.target).value)" />
          <input type="text" placeholder="Ingredient" [value]="store.ingredientQuery()" (input)="store.ingredientQuery.set($any($event.target).value)" />
          <input type="text" placeholder="Cuisine" [value]="store.cuisineQuery()" (input)="store.cuisineQuery.set($any($event.target).value)" />
        </div>
      </div>

      <div class="grid">
        <recipe-card *ngFor="let r of store.filteredRecipes()" [recipe]="r"></recipe-card>
      </div>
    </section>
  `,
})
export class RecipesPage {
  constructor(public store: RecipeStore) {}
}
