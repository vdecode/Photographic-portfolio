import { Component, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RecipeStore } from '../../core/store/recipe.store';

@Component({
  selector: 'favourites-page',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section>
      <h2>Favourites</h2>
      <div *ngIf="favList.length === 0" class="muted">You haven't added favourites yet.</div>
      <div class="grid" *ngIf="favList.length > 0">
        <div *ngFor="let r of favList" class="card">
          <h4 style="margin:0">{{ r.title }}</h4>
          <div class="muted">{{ r.cuisine }}</div>
          <div style="margin-top:0.5rem">
            <button (click)="remove(r.id)" style="padding:0.4rem;border-radius:8px;border:1px solid #eee;cursor:pointer">Remove</button>
          </div>
        </div>
      </div>
    </section>
  `,
})
export class FavouritesPage {
  favList: any[] = [];
  constructor(public store: RecipeStore){
    // effect to update favList reactively when recipes or favourites change
    effect(() => {
      const favIds = Array.from(this.store.favourites());
      this.favList = this.store.recipes().filter(r => favIds.includes(r.id));
    });
  }

  remove(id: number){ this.store.toggleFavourite(id); }
}
