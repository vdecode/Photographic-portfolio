import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { NavbarComponent } from './components/navbar/navbar.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterModule, NavbarComponent],
  template: `
    <div class="container">
      <header class="nav">
        <div class="logo">What's To Cook</div>
        <navbar></navbar>
      </header>

      <main>
        <router-outlet></router-outlet>
      </main>

      <footer>
        Built with Angular Signals — demo for resume
      </footer>
    </div>
  `,
})
export class AppComponent {}
