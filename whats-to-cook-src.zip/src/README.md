    # What's To Cook - src folder

This is a modern, resume-ready Angular 17+ project scaffold using Signals for state.

## How to use
1. Create a new Angular 17 project (or drop this `src/` into an existing project).
2. Ensure dependencies: Angular 17, @angular/common, @angular/router, @angular/core.
3. Run `npm install` and `ng serve`.

## Features
- Recipes fetched from https://dummyjson.com/recipes
- Live search (title, ingredient, cuisine) using Signals
- Favourites persisted to localStorage
- Simple mock login stored in localStorage
- Dark mode toggle persisted in localStorage

## Notes
- This scaffold uses standalone components and a small, opinionated store (signals).
- If you want, I can also produce `package.json`, `angular.json`, and a finished repo to run directly.
