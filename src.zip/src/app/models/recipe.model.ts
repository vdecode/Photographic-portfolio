export interface Recipe {
  id: number;
  title: string;
  cuisine: string;
  ingredients: string[];
  instructions?: string | string[];
  images?: string[];
  image?: string;
}
