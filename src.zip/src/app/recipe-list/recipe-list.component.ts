import { Component } from '@angular/core';
import { RecipeStore } from '../stores/recipe.store';
import { Observable } from 'rxjs';
import { Recipe } from '../models/recipe.model';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-recipe-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
  <!--
  <div class="mb-3">
    <input class="form-control mb-2" placeholder="Search name..." (input)="onSearch($any($event.target).value)" />
    <input class="form-control mb-2" placeholder="Ingredient..." (input)="store.setIngredient($any($event.target).value)" />
    <input class="form-control mb-2" placeholder="Cuisine..." (input)="store.setCuisine($any($event.target).value)" />
  </div>
  -->
  <div class="d-flex gap-2 align-items-center mb-3">
        <input class="form-control" style="max-width:300px" placeholder="Search title/instruction" (input)="onSearch($any($event.target).value)" />
        <input class="form-control" style="max-width:200px" placeholder="Ingredient" (input)="onIngredient($any($event.target).value)" />
        <input class="form-control" style="max-width:200px" placeholder="Cuisine" (input)="onCuisine($any($event.target).value)" />
        <a routerLink='/shopping' class="btn btn-secondary ms-auto">Shopping List</a>
        <a routerLink='/favorites' class="btn btn-outline-secondary">Favorites</a>
      </div>

  <div class="row g-3">
    <div class="col-md-4" *ngFor="let r of filtered$ | async">
      <div class="recipe-card">
        <img [src]="r.images?.[0] || 'https://via.placeholder.com/400x250?text=No+Image'" />
        <h5>{{ r.title }}</h5>
        <p><small>{{ r.cuisine }}</small></p>
        <button class="btn btn-sm btn-outline-primary" (click)="store.toggleFavorite(r.id)">
          {{ (favorites$ | async)?.includes(r.id) ? 'Remove from Favorites' : 'Add to Favorites' }}
        </button>
      </div>
    </div>
  </div>
  `,
})
export class RecipeListComponent {
  filtered$: Observable<Recipe[]>;
  favorites$: Observable<number[]>;
  constructor(public store: RecipeStore){
    this.filtered$ = this.store.filtered$;
    this.favorites$ = this.store.favorites$;
  }
  onSearch(v:string){ this.store.setSearch(v); }
  onIngredient(v:string){ this.store.setIngredient(v); }
  onCuisine(v:string){ this.store.setCuisine(v); }
  toggleFav(id:number){ this.store.toggleFavorite(id); }
}