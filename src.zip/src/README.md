    # Recipe Store (src only)

Drop this `src/` into an Angular 17+ project and run `npm install` then `ng serve`.

Features:
- RxJS store for recipes + filters
- Favorites persisted to localStorage
- Images + titles shown in lists and detail (normalized)
- Dark mode toggle using a signal
