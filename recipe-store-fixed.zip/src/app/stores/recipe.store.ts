import { Injectable, signal, computed, effect } from '@angular/core';
import { Recipe } from '../models/recipe.model';
import { RecipeService } from '../services/recipe.service';
import { toSignal } from '@angular/core/rxjs-interop';

/*
  RecipeStore responsibilities (simple and safe):
  - Store raw recipes in a single signal `recipes`.
  - Expose writable signals for UI inputs (searchQuery, ingredientFilter, cuisineFilter).
  - Use a `computed` for `filteredRecipes` so we avoid writing inside effects.
  - Persist favorites to localStorage via an effect that only reads signals.
  - Keep code straightforward to follow; minimal signal API surface.
*/

@Injectable({ providedIn: 'root' })
export class RecipeStore {
  recipes = signal<Recipe[]>([]); // source of truth for recipe data
  selectedRecipeId = signal<number | null>(null);

  // favorites as a Set for fast membership checks
  favorites = signal<Set<number>>(new Set());

  // UI signals
  searchQuery = signal<string>('');
  ingredientFilter = signal<string>('');
  cuisineFilter = signal<string>('');

  // Computed derived list - automatically updates when signals used inside change.
  filteredRecipes = computed(() => {
    const q = this.searchQuery().trim().toLowerCase();
    const ing = this.ingredientFilter().trim().toLowerCase();
    const cuisine = this.cuisineFilter().trim().toLowerCase();

    return this.recipes().filter(r => {
      const title = (r.title || '').toLowerCase();
      const matchesQ = q ? (title.includes(q) || (r.instructions || '').toLowerCase().includes(q)) : true;
      const matchesCuisine = cuisine ? (r.cuisine || '').toLowerCase().includes(cuisine) : true;
      const matchesIngredient = ing ? (r.ingredients?.some(i => i.toLowerCase().includes(ing)) ?? false) : true;

      return matchesQ && matchesCuisine && matchesIngredient;
    });
  });

  constructor(private api: RecipeService) {
    // Load recipes via RxJS interop -> push to recipes signal
    const recipes$ = this.api.fetchAll(100);
    const recipesSignal = toSignal(recipes$, { initialValue: [] as Recipe[] });

    effect(() => {
      const arr = recipesSignal();
      if (arr && arr.length) {
        this.recipes.set(arr);
      }
    });

    // Hydrate favorites from localStorage at startup (one-time read)
    const raw = localStorage.getItem('recipe_favorites');
    if (raw) {
      try {
        const arr = JSON.parse(raw) as number[];
        this.favorites.set(new Set(arr));
      } catch (e) {
        // ignore parse errors
      }
    }

    // Persist favorites whenever it changes. This effect only reads the signal
    // and writes to localStorage (no signal writes), so it's safe.
    effect(() => {
      const arr = Array.from(this.favorites());
      localStorage.setItem('recipe_favorites', JSON.stringify(arr));
    });
  }

  setSelected(id: number | null) {
    this.selectedRecipeId.set(id);
  }

  toggleFavorite(id: number) {
    const s = new Set(this.favorites());
    if (s.has(id)) s.delete(id); else s.add(id);
    this.favorites.set(s);
  }

  addRecipe(recipe: Recipe) {
    this.recipes.update(curr => [recipe, ...curr]);
  }

  removeRecipe(id: number) {
    this.recipes.update(curr => curr.filter(r => r.id !== id));
  }
}
