import { Component } from '@angular/core';
import { RecipeStore } from '../stores/recipe.store';

@Component({
  selector: 'favorites-page',
  standalone: true,
  template: `
    <section>
      <h2>Favorites</h2>
      <div *ngIf="favRecipes.length === 0">No favorites yet</div>
      <div *ngFor="let r of favRecipes">
        <h4>{{ r.title }}</h4>
        <button (click)="store.toggleFavorite(r.id)">Remove</button>
      </div>
    </section>
  `,
})
export class FavoritesComponent {
  favRecipes = [] as any[];
  constructor(public store: RecipeStore) {
    # subscribe to recipes signal changes and derive favorite list
    store.recipes.subscribe(recipes => {
      const favIds = new Set(store.favorites());
      this.favRecipes = recipes.filter(r => favIds.has(r.id));
    });
  }
}
