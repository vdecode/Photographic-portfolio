import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { DarkModeToggleComponent } from './dark-mode-toggle/dark-mode-toggle.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterModule, DarkModeToggleComponent],
  template: `
    <div class="app-shell">
      <header style="display:flex; align-items:center; justify-content:space-between;">
        <h1>Recipe Store</h1>
        <dark-mode-toggle></dark-mode-toggle>
      </header>

      <main style="margin-top:1rem">
        <router-outlet></router-outlet>
      </main>
    </div>
  `,
})
export class AppComponent {}
