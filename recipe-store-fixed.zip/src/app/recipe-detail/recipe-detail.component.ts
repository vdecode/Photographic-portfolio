import { Component, effect } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RecipeStore } from '../stores/recipe.store';

@Component({
  selector: 'recipe-detail',
  standalone: true,
  template: `
    <section *ngIf="recipe">
      <h2>{{ recipe.title }}</h2>
      <p style=\"color:var(--muted)\">{{ recipe.cuisine }}</p>
      <img *ngIf="recipe.images?.length" [src]="recipe.images[0]" alt="" style="max-width:320px;" />
      <h3>Ingredients</h3>
      <ul>
        <li *ngFor="let i of recipe.ingredients">{{ i }}</li>
      </ul>
      <h3>Instructions</h3>
      <p>{{ recipe.instructions }}</p>
      <button (click)="toggleFav(recipe.id)">{{ store.favorites().has(recipe.id) ? 'Remove Favorite' : 'Add to Favorites' }}</button>
    </section>
  `,
})
export class RecipeDetailComponent {
  recipe: any = null;

  constructor(private route: ActivatedRoute, public store: RecipeStore) {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    // Use an effect to reactively pick the recipe from store.recipes
    effect(() => {
      const list = this.store.recipes();
      this.recipe = list.find(r => Number(r.id) === Number(id)) || null;
    });
  }

  toggleFav(id: number) {
    this.store.toggleFavorite(id);
  }
}
