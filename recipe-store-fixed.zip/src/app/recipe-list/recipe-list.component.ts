import { Component } from '@angular/core';
import { NgFor, NgIf } from '@angular/common';
import { RecipeStore } from '../stores/recipe.store';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'recipe-list',
  standalone: true,
  imports: [NgFor, NgIf, RouterLink],
  template: `
    <section>
      <div style="display:flex; gap:1rem; align-items:center;">
        <input placeholder="Search title or instruction" [value]="store.searchQuery()" (input)="store.searchQuery.set($any($event.target).value)" />
        <input placeholder="Ingredient" [value]="store.ingredientFilter()" (input)="store.ingredientFilter.set($any($event.target).value)" />
        <input placeholder="Cuisine" [value]="store.cuisineFilter()" (input)="store.cuisineFilter.set($any($event.target).value)" />
        <a routerLink='/shopping'><button>Generate Shopping List</button></a>
        <a routerLink='/favorites'><button>Favorites</button></a>
      </div>

      <div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(240px,1fr)); gap:1rem; margin-top:1rem">
        <div *ngFor="let r of store.filteredRecipes()" class="recipe-card">
          <h3>{{ r.title }}</h3>
          <p style=\"font-size:0.9rem; color:var(--muted)\">{{ r.cuisine }}</p>
          <p>{{ r.ingredients?.length || 0 }} ingredients</p>
          <div style=\"display:flex; gap:0.5rem; margin-top:0.5rem\">
            <a [routerLink]="['/recipe', r.id]">View</a>
            <button (click)="toggleFav(r.id)">{{ store.favorites().has(r.id) ? 'Unfav' : 'Fav' }}</button>
          </div>
        </div>
      </div>
    </section>
  `,
})
export class RecipeListComponent {
  constructor(public store: RecipeStore) {}

  toggleFav(id: number) {
    this.store.toggleFavorite(id);
  }
}
