// Recipe model adapted for DummyJSON: https://dummyjson.com/recipes
// For DummyJSON each recipe's ingredients are strings in an array.

export interface Recipe {
  id: number;
  title: string;
  cuisine?: string;
  ingredients: string[];
  instructions?: string;
  images?: string[];
  thumbnail?: string;
  servings?: number;
}
