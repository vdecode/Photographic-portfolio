import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Recipe } from '../models/recipe.model';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class RecipeService {
  // User-provided API
  private readonly API = 'https://dummyjson.com/recipes';

  constructor(private http: HttpClient) {}

  // Return an observable of Recipe[] by mapping DummyJSON envelope to array.
  fetchAll(limit = 100): Observable<Recipe[]> {
    const url = `${this.API}?limit=${limit}`;
    return this.http.get<any>(url).pipe(map(res => res?.recipes || []));
  }

  fetchById(id: number) {
    return this.http.get<Recipe>(`${this.API}/${id}`);
  }
}
