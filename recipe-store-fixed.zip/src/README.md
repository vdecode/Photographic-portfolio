# Recipe Store (Fixed) - src folder

## What I fixed
- Removed unsafe signal writes inside `effect()` which caused `NG0600` runtime errors.
- Implemented `filteredRecipes` as a `computed()` to derive filtered lists reactively (no signal writes).
- Persisted favorites via an effect that only reads signals and writes to localStorage.
- Updated RecipeService to map DummyJSON envelope to `Recipe[]` directly.
- Kept code simple and readable with intermediate-level comments. No deep signal patterns.

## How to use
1. Drop `src/` into an Angular 17+ standalone project.
2. `npm install` and `ng serve`.
3. App will fetch from https://dummyjson.com/recipes by default.
