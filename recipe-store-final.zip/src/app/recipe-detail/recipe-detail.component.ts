import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { RecipeStore } from '../stores/recipe.store';

@Component({
  selector: 'recipe-detail',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section *ngIf="recipe">
      <h2>{{ recipe.title }}</h2>
      <p class="text-muted">{{ recipe.cuisine }}</p>
      <img *ngIf="recipe.images?.length" [src]="recipe.images[0]" class="img-fluid mb-2 rounded" style="max-width:320px; object-fit:cover;" />
      <h5>Ingredients</h5>
      <ul><li *ngFor="let i of recipe.ingredients">{{ i }}</li></ul>
      <h5>Instructions</h5>
      <p>{{ instructionsStr }}</p>
      <button class="btn btn-sm btn-outline-primary" (click)="toggleFav(recipe.id)">{{ isFav ? 'Remove Favorite' : 'Add to Favorites' }}</button>
    </section>
  `
})
export class RecipeDetailComponent{
  recipe:any=null;
  isFav=false;
  instructionsStr='';
  constructor(private route:ActivatedRoute,private store:RecipeStore){
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.recipe = this.store.getRecipeById(id) || null;
    this.isFav = this.recipe && this.store.favoritesSubject.getValue().includes(id);
    if(this.recipe){
        this.instructionsStr = Array.isArray(this.recipe.instructions)?this.recipe.instructions.join(' '):(this.recipe.instructions||'');
    }
  }
  toggleFav(id:number){ this.store.toggleFavorite(id); this.isFav = !this.isFav; }
}
