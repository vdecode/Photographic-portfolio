import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RecipeStore } from '../stores/recipe.store';
import { Observable, map } from 'rxjs';
import { Recipe } from '../models/recipe.model';

@Component({
  selector: 'favorites-page',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section>
      <h2>Favorites</h2>
      <div *ngIf="(favRecipes$ | async)?.length===0">No favorites yet</div>
      <div *ngFor="let r of (favRecipes$ | async)" class="mb-3">
        <img *ngIf="r.images?.length" [src]="r.images[0]" class="img-fluid mb-1 rounded" style="max-height:120px; width:100%; object-fit:cover;" />
        <h5>{{ r.title }}</h5>
        <p class="text-muted small">{{ r.cuisine }}</p>
        <button class="btn btn-sm btn-outline-primary" (click)="toggleFav(r.id)">Remove</button>
      </div>
    </section>
  `
})
export class FavoritesComponent{
  favRecipes$:Observable<Recipe[]>;
  constructor(private store:RecipeStore){
    this.favRecipes$ = this.store.favorites$.pipe(map(favIds=>{
      const all = this.store.recipesSubject.getValue();
      return all.filter(r=>favIds.includes(r.id));
    }));
  }
  toggleFav(id:number){ this.store.toggleFavorite(id); }
}
