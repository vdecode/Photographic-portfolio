import { Injectable } from '@angular/core';
import { BehaviorSubject, combineLatest, map } from 'rxjs';
import { Recipe } from '../models/recipe.model';
import { RecipeService } from '../services/recipe.service';

@Injectable({ providedIn: 'root' })
export class RecipeStore {
  recipesSubject = new BehaviorSubject<Recipe[]>([]);
  recipes$ = this.recipesSubject.asObservable();

  private searchQuery$ = new BehaviorSubject<string>('');
  private ingredientFilter$ = new BehaviorSubject<string>('');
  private cuisineFilter$ = new BehaviorSubject<string>('');

  favoritesSubject = new BehaviorSubject<number[]>([]);
  favorites$ = this.favoritesSubject.asObservable();

  filteredRecipes$ = combineLatest([
    this.recipes$,
    this.searchQuery$,
    this.ingredientFilter$,
    this.cuisineFilter$
  ]).pipe(
    map(([recipes, q, ing, cuisine]) => {
      q = (q||'').trim().toLowerCase();
      ing = (ing||'').trim().toLowerCase();
      cuisine = (cuisine||'').trim().toLowerCase();
      return recipes.filter(r => {
        const title = (r.title||'').toLowerCase();
        const instructionsStr = Array.isArray(r.instructions) ? r.instructions.join(' ').toLowerCase() : (r.instructions||'').toLowerCase();
        const matchesQ = q ? (title.includes(q) || instructionsStr.includes(q)) : true;
        const matchesCuisine = cuisine ? ((r.cuisine||'').toLowerCase().includes(cuisine)) : true;
        const matchesIngredient = ing ? (r.ingredients||[]).some(i=>i.toLowerCase().includes(ing)) : true;
        return matchesQ && matchesCuisine && matchesIngredient;
      });
    })
  );

  constructor(private api: RecipeService) {
    this.api.fetchAll(100).subscribe({
      next: arr => this.recipesSubject.next(arr),
      error: () => this.recipesSubject.next([])
    });
    const raw = localStorage.getItem('recipe_favorites');
    if(raw) {
      try { this.favoritesSubject.next(JSON.parse(raw)); } catch(e) {}
    }
    this.favorites$.subscribe(arr => localStorage.setItem('recipe_favorites', JSON.stringify(arr||[])));
  }

  setSearch(q:string){ this.searchQuery$.next(q); }
  setIngredientFilter(v:string){ this.ingredientFilter$.next(v); }
  setCuisineFilter(v:string){ this.cuisineFilter$.next(v); }

  toggleFavorite(id:number){
    const arr = Array.from(new Set(this.favoritesSubject.getValue()));
    const idx = arr.indexOf(id);
    if(idx===-1) arr.push(id); else arr.splice(idx,1);
    this.favoritesSubject.next(arr);
  }

  getRecipeById(id:number) { return this.recipesSubject.getValue().find(r=>r.id===id); }

  generateShoppingList(fromIds?:number[]):string[]{
    const recipes = this.recipesSubject.getValue();
    const ids = (fromIds && fromIds.length)?fromIds:this.favoritesSubject.getValue();
    const set = new Set<string>();
    recipes.forEach(r=>{ if(ids.length===0 || ids.includes(r.id)) (r.ingredients||[]).forEach(i=>set.add(i)) });
    return Array.from(set);
  }
}
