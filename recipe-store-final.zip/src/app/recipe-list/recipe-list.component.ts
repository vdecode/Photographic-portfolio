import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { RecipeStore } from '../stores/recipe.store';
import { Observable } from 'rxjs';
import { Recipe } from '../models/recipe.model';

@Component({
  selector: 'recipe-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <section>
      <div class="d-flex gap-2 align-items-center mb-3">
        <input class="form-control" style="max-width:300px" placeholder="Search title/instruction" (input)="onSearch($any($event.target).value)" />
        <input class="form-control" style="max-width:200px" placeholder="Ingredient" (input)="onIngredient($any($event.target).value)" />
        <input class="form-control" style="max-width:200px" placeholder="Cuisine" (input)="onCuisine($any($event.target).value)" />
        <a routerLink='/shopping' class="btn btn-secondary ms-auto">Shopping List</a>
        <a routerLink='/favorites' class="btn btn-outline-secondary">Favorites</a>
      </div>

      <div class="row g-3">
        <div class="col-12 col-md-6 col-lg-4" *ngFor="let r of (recipes$ | async)">
          <div class="recipe-card">
            <img *ngIf="r.images?.length" [src]="r.images[0]" class="img-fluid mb-2 rounded" style="max-height:150px; width:100%; object-fit:cover;" />
            <h5>{{ r.title }}</h5>
            <p class="text-muted small mb-1">{{ r.cuisine }}</p>
            <p class="small mb-2">{{ r.ingredients?.length || 0 }} ingredients</p>
            <div class="d-flex gap-2">
              <a [routerLink]="['/recipe', r.id]" class="btn btn-sm btn-link">View</a>
              <button class="btn btn-sm btn-outline-primary" (click)="toggleFav(r.id)">{{ (favorites$ | async)?.includes(r.id) ? 'Unfav' : 'Fav' }}</button>
            </div>
          </div>
        </div>
      </div>
    </section>
  `,
})
export class RecipeListComponent {
  recipes$: Observable<Recipe[]>;
  favorites$ = this.store.favorites$;
  constructor(private store: RecipeStore){ this.recipes$ = this.store.filteredRecipes$; }
  onSearch(v:string){ this.store.setSearch(v); }
  onIngredient(v:string){ this.store.setIngredientFilter(v); }
  onCuisine(v:string){ this.store.setCuisineFilter(v); }
  toggleFav(id:number){ this.store.toggleFavorite(id); }
}
