import { Injectable } from '@angular/core';
import { BehaviorSubject, combineLatest, map } from 'rxjs';
import { Recipe } from '../models/recipe.model';
import { RecipeService } from '../services/recipe.service';

/*
  RecipeStore (RxJS):
  - Uses BehaviorSubject for mutable state (recipes, filters, favorites).
  - Exposes observables for UI via `asObservable()` or derived streams like filteredRecipes$.
  - Persists favorites to localStorage on updates.
*/

@Injectable({ providedIn: 'root' })
export class RecipeStore {
  // source data
  recipesSubject = new BehaviorSubject<Recipe[]>([]);
  recipes$ = this.recipesSubject.asObservable();

  // UI state as subjects
  private searchQuery$ = new BehaviorSubject<string>('');
  private ingredientFilter$ = new BehaviorSubject<string>('');
  private cuisineFilter$ = new BehaviorSubject<string>('');

  // favorites stored as array of ids
  favoritesSubject = new BehaviorSubject<number[]>([]);
  favorites$ = this.favoritesSubject.asObservable();

  // Derived filtered recipes observable using combineLatest - reactive and simple
  filteredRecipes$ = combineLatest([
    this.recipes$,
    this.searchQuery$,
    this.ingredientFilter$,
    this.cuisineFilter$
  ]).pipe(
    map(([recipes, q, ing, cuisine]) => {
      q = (q || '').trim().toLowerCase();
      ing = (ing || '').trim().toLowerCase();
      cuisine = (cuisine || '').trim().toLowerCase();

      return recipes.filter(r => {
        const title = (r.title || '').toLowerCase();
        const matchesQ = q ? (title.includes(q) || (r.instructions || '').toLowerCase().includes(q)) : true;
        const matchesCuisine = cuisine ? ((r.cuisine || '') .toLowerCase().includes(cuisine)) : true;
        const matchesIngredient = ing ? (r.ingredients || []).some(i => i.toLowerCase().includes(ing)) : true;
        return matchesQ && matchesCuisine && matchesIngredient;
      });
    })
  );

  constructor(private api: RecipeService) {
    // load recipes once
    this.api.fetchAll(100).subscribe({
      next: (arr) => this.recipesSubject.next(arr),
      error: () => this.recipesSubject.next([])
    });

    // hydrate favorites from localStorage once
    const raw = localStorage.getItem('recipe_favorites');
    if (raw) {
      try {
        const arr = JSON.parse(raw) as number[];
        this.favoritesSubject.next(arr);
      } catch(e) {}
    }

    // persist favorites on change
    this.favorites$.subscribe(arr => {
      localStorage.setItem('recipe_favorites', JSON.stringify(arr || []));
    });
  }

  // UI setters
  setSearch(q: string) { this.searchQuery$.next(q); }
  setIngredientFilter(v: string) { this.ingredientFilter$.next(v); }
  setCuisineFilter(v: string) { this.cuisineFilter$.next(v); }

  // favorites
  toggleFavorite(id: number) {
    const arr = Array.from(new Set(this.favoritesSubject.getValue()));
    const idx = arr.indexOf(id);
    if (idx === -1) arr.push(id); else arr.splice(idx, 1);
    this.favoritesSubject.next(arr);
  }

  // helpers
  getRecipeById(id: number): Recipe | undefined {
    return this.recipesSubject.getValue().find(r => r.id === id);
  }

  // shopping list: combine ingredients from given ids or favorites
  generateShoppingList(fromIds?: number[]): string[] {
    const recipes = this.recipesSubject.getValue();
    const ids = (fromIds && fromIds.length) ? fromIds : this.favoritesSubject.getValue();
    const set = new Set<string>();
    recipes.forEach(r => {
      if (ids.length === 0 || ids.includes(r.id)) {
        (r.ingredients || []).forEach(i => set.add(i));
      }
    });
    return Array.from(set);
  }
}
