// Recipe model for DummyJSON recipes (ingredients as string[])
export interface Recipe {
  id: number;
  title: string;
  cuisine?: string;
  ingredients: string[];
  instructions?: string;
  images?: string[];
  thumbnail?: string;
}
