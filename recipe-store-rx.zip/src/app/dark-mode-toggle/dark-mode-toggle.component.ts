import { Component } from '@angular/core';
import { signal, effect } from '@angular/core';

@Component({
  selector: 'dark-mode-toggle',
  standalone: true,
  template: `<button class="btn btn-sm btn-outline-dark" (click)="toggle()">{{ mode() ? 'Light' : 'Dark' }}</button>`,
})
export class DarkModeToggleComponent {
  mode = signal<boolean>(false);
  constructor() {
    const raw = localStorage.getItem('dark_mode');
    this.mode.set(raw === '1');
    effect(() => {
      const m = this.mode();
      const el = document.documentElement;
      if (m) el.classList.add('dark'); else el.classList.remove('dark');
      localStorage.setItem('dark_mode', m ? '1' : '0');
    });
  }
  toggle() { this.mode.update(v => !v); }
}
