import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { RecipeStore } from '../stores/recipe.store';

@Component({
  selector: 'recipe-detail',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section *ngIf="recipe">
      <h2>{{ recipe.title }}</h2>
      <p class="text-muted">{{ recipe.cuisine }}</p>
      <img *ngIf="recipe.images?.length" [src]="recipe.images[0]" class="img-fluid mb-2" style="max-width:320px" />
      <h5>Ingredients</h5>
      <ul><li *ngFor="let i of recipe.ingredients">{{ i }}</li></ul>
      <h5>Instructions</h5>
      <p>{{ recipe.instructions }}</p>
      <button class="btn btn-sm btn-outline-primary" (click)="toggleFav(recipe.id)">{{ isFav ? 'Remove Favorite' : 'Add to Favorites' }}</button>
    </section>
  `,
})
export class RecipeDetailComponent {
  recipe: any = null;
  isFav = false;

  constructor(private route: ActivatedRoute, private store: RecipeStore) {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.recipe = this.store.getRecipeById(id) || null;
    const favs = this.store.favoritesSubject.getValue();
    this.isFav = favs.includes(id);
  }

  toggleFav(id: number) { this.store.toggleFavorite(id); this.isFav = !this.isFav; }
}
