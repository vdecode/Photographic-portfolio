import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RecipeStore } from '../stores/recipe.store';

@Component({
  selector: 'shopping-list',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section>
      <h2>Shopping List</h2>
      <p *ngIf="ingredients.length === 0">No ingredients selected</p>
      <ul><li *ngFor="let ing of ingredients">{{ ing }}</li></ul>
      <div class="mt-3">
        <button class="btn btn-sm btn-secondary" (click)="clear()">Clear</button>
        <button class="btn btn-sm btn-outline-secondary" (click)="export()">Export (copy)</button>
      </div>
    </section>
  `,
})
export class ShoppingListComponent {
  ingredients: string[] = [];
  constructor(private store: RecipeStore) {
    this.ingredients = this.store.generateShoppingList();
  }
  clear() { this.ingredients = []; }
  export() { navigator.clipboard?.writeText(this.ingredients.join('\n')).then(()=>alert('Copied')) }
}
