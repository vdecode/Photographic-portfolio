import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RecipeStore } from '../stores/recipe.store';
import { Observable, map } from 'rxjs';
import { Recipe } from '../models/recipe.model';

@Component({
  selector: 'favorites-page',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section>
      <h2>Favorites</h2>
      <div *ngIf="(favRecipes$ | async)?.length === 0">No favorites yet</div>
      <div *ngFor="let r of (favRecipes$ | async)">
        <h4>{{ r.title }}</h4>
        <button class="btn btn-sm btn-outline-primary" (click)="toggleFav(r.id)">Remove</button>
      </div>
    </section>
  `,
})
export class FavoritesComponent {
  favRecipes$: Observable<Recipe[]>;
  constructor(private store: RecipeStore) {
    this.favRecipes$ = this.store.filteredRecipes$.pipe(
      map(recipes => recipes.filter(r => this.store.favoritesSubject.getValue().includes(r.id)))
    );
  }
  toggleFav(id: number) { this.store.toggleFavorite(id); }
}
