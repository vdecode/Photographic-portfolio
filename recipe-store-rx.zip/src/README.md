# Recipe Store (RxJS + Minimal Signals) - src folder

## Summary
- Uses RxJS BehaviorSubjects for data and filters (reliable for real apps).
- Uses a minimal Angular signal only for dark mode toggle.
- Fetches from https://dummyjson.com/recipes.
- Plain Bootstrap-based layout. Drop into Angular 17+ project `src/`.

## Run
- Place inside an Angular 17+ project's `src/`.
- Ensure Angular packages are 17+.
- Run `npm install` and `ng serve`.
