import { Injectable, signal, computed, effect } from '@angular/core';
import { Recipe } from '../models/recipe.model';
import { RecipeService } from '../services/recipe.service';
import { toSignal } from '@angular/core/rxjs-interop';

// RecipeStore centralizes signals for recipes, filters, favorites and selection.
// Intermediate comments explain the reasoning:
// - Keep raw data signal (`recipes`) as the single source of truth for recipe items.
// - Expose writable signals for UI state (filters, selectedRecipeId).
// - Use `computed` to derive filtered lists — cheap, cached, and updates reactively.
// - Use `effect` for side-effects (persisting favorites, hydrating from localStorage).

@Injectable({ providedIn: 'root' })
export class RecipeStore {
  // raw recipes loaded from API
  recipes = signal<Recipe[]>([]);

  // currently selected recipe id (nullable)
  selectedRecipeId = signal<number | null>(null);

  // favorites stored as a Set of recipe ids for O(1) membership checks.
  favorites = signal<Set<number>>(new Set());

  // filters / search inputs as simple writable signals
  searchQuery = signal<string>('');
  ingredientFilter = signal<string>('');
  cuisineFilter = signal<string>('');

  // computed: reactive, memoized filtered array based on recipes + filters.
  filteredRecipes = computed(() => {
    const q = this.searchQuery().trim().toLowerCase();
    const ing = this.ingredientFilter().trim().toLowerCase();
    const cuisine = this.cuisineFilter().trim().toLowerCase();

    return this.recipes().filter(r => {
      const title = (r.title || '').toLowerCase();
      const matchesQ = q ? title.includes(q) || (r.instructions || '').toLowerCase().includes(q) : true;

      const matchesCuisine = cuisine ? (r.cuisine || '').toLowerCase().includes(cuisine) : true;

      const matchesIngredient = ing
        ? r.ingredients.some(i => i.toLowerCase().includes(ing))
        : true;

      return matchesQ && matchesCuisine && matchesIngredient;
    });
  });

  constructor(private api: RecipeService) {
    // fetch recipes using RxJS interop and push to our `recipes` signal
    const recipes$ = this.api.fetchAll({ limit: 100 }); // try to fetch many for local dev
    const recipesSignal = toSignal(recipes$, { initialValue: null });

    // effect watches the recipesSignal and writes to `recipes` signal when data arrives.
    effect(() => {
      const envelope = recipesSignal();
      if (envelope && envelope.recipes) {
        // dummyjson returns { recipes: Recipe[], total, ... }
        this.recipes.set(envelope.recipes as Recipe[]);
      } else if (Array.isArray(envelope)) {
        // in case the endpoint returns raw array
        this.recipes.set(envelope as Recipe[]);
      }
    });

    // hydrate favorites once from localStorage on startup
    const raw = localStorage.getItem('recipe_favorites');
    if (raw) {
      try {
        const arr = JSON.parse(raw) as number[];
        this.favorites.set(new Set(arr));
      } catch (e) {
        // ignore parse errors - start fresh
      }
    }

    // persist favorites whenever it changes — effect automatically subscribes to the signal
    effect(() => {
      const arr = Array.from(this.favorites());
      localStorage.setItem('recipe_favorites', JSON.stringify(arr));
    });
  }

  setSelected(id: number | null) {
    this.selectedRecipeId.set(id);
  }

  toggleFavorite(id: number) {
    const s = new Set(this.favorites());
    if (s.has(id)) s.delete(id); else s.add(id);
    this.favorites.set(s);
  }

  addRecipe(recipe: Recipe) {
    this.recipes.update(curr => [recipe, ...curr]);
  }

  removeRecipe(id: number) {
    this.recipes.update(curr => curr.filter(r => r.id !== id));
  }
}
