import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Recipe } from '../models/recipe.model';

// Service focuses on fetching recipes from DummyJSON.
// We keep methods minimal: fetch all (with optional pagination) and fetch by id.
//
// Note: DummyJSON returns a paginated envelope for some endpoints:
// GET https://dummyjson.com/recipes  -> { recipes: Recipe[], total: number, skip: number, limit: number }
//
// We map that envelope to an array for consumers to keep store logic simple.

@Injectable({ providedIn: 'root' })
export class RecipeService {
  // base API - user-provided
  private readonly API = 'https://dummyjson.com/recipes';

  constructor(private http: HttpClient) {}

  // returns the full envelope; callers can pick `.recipes` or adapt as needed
  fetchAll(params: { limit?: number; skip?: number } = {}) {
    const url = this.API + (params.limit ? `?limit=${params.limit}&skip=${params.skip || 0}` : '');
    return this.http.get<any>(url);
  }

  fetchById(id: number) {
    return this.http.get<Recipe>(`${this.API}/${id}`);
  }
}
