import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Recipe } from '../models/recipe.model';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class RecipeService {
  private readonly API = 'https://dummyjson.com/recipes';
  constructor(private http: HttpClient) {}

  fetchAll(limit = 100): Observable<Recipe[]> {
    return this.http.get<any>(`${this.API}?limit=${limit}`).pipe(
      map(res => (res?.recipes || []).map((r: any) => ({
        id: r.id,
        title: r.title || r.name || 'Unknown Recipe',
        cuisine: r.cuisine || 'Unknown',
        ingredients: Array.isArray(r.ingredients) ? r.ingredients : (r.ingredients ? [String(r.ingredients)] : []),
        instructions: r.instructions || r.steps || '',
        images: Array.isArray(r.images) && r.images.length ? r.images : (r.thumbnail ? [r.thumbnail] : ['https://via.placeholder.com/400x250?text=No+Image']),
      })) )
    );
  }

  fetchById(id: number): Observable<Recipe> {
    return this.http.get<Recipe>(`${this.API}/${id}`).pipe(
      map((r: any) => ({
        id: r.id,
        title: r.title || r.name || 'Unknown Recipe',
        cuisine: r.cuisine || 'Unknown',
        ingredients: Array.isArray(r.ingredients) ? r.ingredients : (r.ingredients ? [String(r.ingredients)] : []),
        instructions: r.instructions || r.steps || '',
        images: Array.isArray(r.images) && r.images.length ? r.images : (r.thumbnail ? [r.thumbnail] : ['https://via.placeholder.com/400x250?text=No+Image']),
      }))
    );
  }
}
