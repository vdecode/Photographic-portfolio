import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { DarkModeToggleComponent } from './dark-mode-toggle/dark-mode-toggle.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterModule, DarkModeToggleComponent],
  template: `
    <div class="app-shell container">
      <header class="d-flex align-items-center justify-content-between py-3">
        <h1 class="h4 m-0">Recipe Store</h1>
        <dark-mode-toggle></dark-mode-toggle>
      </header>
      <main class="mt-3">
        <router-outlet></router-outlet>
      </main>
    </div>
  `,
})
export class AppComponent {}
