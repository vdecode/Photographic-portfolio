import { Component } from '@angular/core';
import { RecipeStore } from '../stores/recipe.store';

@Component({
  selector: 'shopping-list',
  standalone: true,
  template: `
    <section>
      <h2>Shopping List</h2>
      <p *ngIf="ingredients.length === 0">No ingredients selected</p>
      <ul>
        <li *ngFor="let ing of ingredients">{{ ing }}</li>
      </ul>
      <div style="margin-top:1rem">
        <button (click)="clear()">Clear</button>
        <button (click)="export()">Export (copy)</button>
      </div>
    </section>
  `,
})
export class ShoppingListComponent {
  ingredients: string[] = [];

  constructor(private store: RecipeStore) {
    // For this scaffold we generate shopping list from favorited recipes.
    // In a real app you would allow selecting recipes for the shopping list explicitly.
    const combined = new Set<string>();
    const favs = Array.from(store.favorites());
    const recipes = store.recipes();
    recipes.forEach(r => {
      if (favs.length === 0 || favs.includes(r.id)) {
        r.ingredients.forEach((i: string) => combined.add(i));
      }
    });
    this.ingredients = Array.from(combined);
  }

  clear() {
    this.ingredients = [];
  }

  export() {
    const text = this.ingredients.join('\n');
    navigator.clipboard?.writeText(text).then(() => alert('Copied to clipboard'));
  }
}
