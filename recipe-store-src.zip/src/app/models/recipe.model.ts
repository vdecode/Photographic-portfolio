// Intermediate-level Recipe model adjusted for DummyJSON (https://dummyjson.com/docs/recipes)
// DummyJSON recipe items commonly contain fields like:
// id, title (or name), cuisine, ingredients (array of strings), instructions, thumbnails/images
//
// We type ingredients as strings because dummyjson provides them that way.

export interface Recipe {
  id: number;
  title: string;           // DummyJSON uses 'title' or 'name' depending on endpoint version; we use title
  cuisine?: string;
  ingredients: string[];   // each ingredient is a plain string (e.g. "2 cups flour")
  instructions?: string;
  images?: string[];       // array of image urls
  thumbnail?: string;
  servings?: number;
  prepTime?: string;
}
