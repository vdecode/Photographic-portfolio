# Recipe Store (Signals) - src folder

## What is included
- Angular 17+ signals-based scaffold for a Recipe Store.
- Connects to DummyJSON recipes API: https://dummyjson.com/recipes
- Intermediate-level comments explaining signals usage (store, computed, effects).

## Structure & Flow (short)
- `RecipeService` fetches data from DummyJSON. The endpoint returns an envelope `{ recipes: [], total, ... }`.
- `RecipeStore` holds the single source of truth `recipes` signal and UI state signals (filters, favorites, selection).
- `filteredRecipes` is a `computed` signal derived from `recipes` + filters.
- `effect()` is used to persist favorites to localStorage and to hydrate them on startup.
- Components consume store signals directly (read-only) and call store methods to mutate state.

## How to use
1. Drop this `src/` into an Angular 17+ standalone project (or replace an existing `src/` folder).
2. `npm install` (ensure @angular/core 17+, @angular/common, etc).
3. `ng serve` and open the app.

## Notes
- The shopping list in this scaffold derives items from favorited recipes for a quick demo. You can extend the store to maintain an explicit `shoppingSelected` signal.
- If the DummyJSON schema changes, adjust `app/models/recipe.model.ts` accordingly.
